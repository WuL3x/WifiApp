﻿namespace KayumovAE2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Button BtnRefresh;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listNet = new System.Windows.Forms.ListView();
            this.SSID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Signal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Type = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Crypt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            BtnRefresh = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnRefresh
            // 
            BtnRefresh.Location = new System.Drawing.Point(584, 12);
            BtnRefresh.Name = "BtnRefresh";
            BtnRefresh.Size = new System.Drawing.Size(195, 51);
            BtnRefresh.TabIndex = 1;
            BtnRefresh.Text = "Обновить";
            BtnRefresh.UseVisualStyleBackColor = true;
            BtnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // listNet
            // 
            this.listNet.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.SSID,
            this.Signal,
            this.Type,
            this.Crypt});
            this.listNet.HideSelection = false;
            this.listNet.LargeImageList = this.imageList1;
            this.listNet.Location = new System.Drawing.Point(12, 12);
            this.listNet.Name = "listNet";
            this.listNet.Size = new System.Drawing.Size(548, 426);
            this.listNet.TabIndex = 0;
            this.listNet.UseCompatibleStateImageBehavior = false;
            this.listNet.View = System.Windows.Forms.View.Details;
            this.listNet.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // SSID
            // 
            this.SSID.Text = "SSID";
            this.SSID.Width = 125;
            // 
            // Signal
            // 
            this.Signal.Text = "Качество";
            this.Signal.Width = 133;
            // 
            // Type
            // 
            this.Type.Text = "Тип безопасности";
            this.Type.Width = 125;
            // 
            // Crypt
            // 
            this.Crypt.Text = "Тип шифрования";
            this.Crypt.Width = 161;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "WIFI.png");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(BtnRefresh);
            this.Controls.Add(this.listNet);
            this.Name = "Form1";
            this.Text = "Wi-fi";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView listNet;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ColumnHeader SSID;
        private System.Windows.Forms.ColumnHeader Signal;
        private System.Windows.Forms.ColumnHeader Type;
        private System.Windows.Forms.ColumnHeader Crypt;
    }
}

